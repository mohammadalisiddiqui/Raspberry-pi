import RPi.GPIO as gpio
import time as t

gpio.setwarnings(False)

gpio.setmode(gpio.BCM)
gpio.setup(21,gpio.OUT)
gpio.output(21,gpio.HIGH)
t.sleep(2)
gpio.output(21,gpio.LOW)