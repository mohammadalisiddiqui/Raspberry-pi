import RPi.GPIO as gpio
import time as t

gpio.setmode(gpio.BCM)
gpio.setup(21, gpio.OUT)

pwm = gpio.PWM(21, 50)

pwm.start(0)
t.sleep(0.1)

pwm.ChangeDutyCycle(2)
t.sleep(0.1)

pwm.stop()
gpio.cleanup()