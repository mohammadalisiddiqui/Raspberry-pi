import RPi.GPIO as gpio
import time

gpio.setmode(gpio.BCM)

gpio.setup(12, gpio.OUT)



while(1):
    gpio.output(12, gpio.HIGH)
    time.sleep(1)
    gpio.output(12, gpio.LOW)
    time.sleep(5)