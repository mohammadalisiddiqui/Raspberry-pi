import cv2
import numpy as np

raw_img = cv2.imread('/home/pi/Desktop/red.jpg')

cv2.imshow('img', raw_img)

red_lower = np.array([170, 112, 255], np.uint8)
red_upper = np.array([180, 255, 255], np.uint8)

img = cv2.cvtColor(raw_img, cv2.COLOR_BGR2HSV)
red_mask = cv2.inRange(img, red_lower, red_upper)

cv2.imshow('img',red_mask)


cv2.waitKey(0)