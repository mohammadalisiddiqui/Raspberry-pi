from gtts import gTTS
import os

text = "Welcome to Artificial Intelligence for Robotics Program"

language = "en"

myspeech = gTTS(text=text, lang=language, slow=False)

myspeech.save("welcome")

os.system("mpg321 welcome.mp3")