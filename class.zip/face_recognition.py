#!/usr/bin/python3
#opencv_display.py
from picamera.array import PiRGBArray
from picamera import PiCamera
import time
import cv2

import opencv_color_detect as PROCESS  

def show_images(images,text,MODE):          
  # show the frame
  cv2.putText...