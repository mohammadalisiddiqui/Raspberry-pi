import RPi.GPIO as gpio
import time
a1 = 11
a2 = 13
b1 = 15
b2 = 12

gpio.setmode(gpio.BOARD)
gpio.setup(a1, gpio.OUT)
gpio.setup(a2, gpio.OUT)
gpio.setup(b1, gpio.OUT)
gpio.setup(b2, gpio.OUT)

gpio.output(a1, gpio.HIGH) #a1 1
time.sleep(0.01)
gpio.output(a2, gpio.LOW) #A2 0
time.sleep(0.01)
gpio.output(b1, gpio.LOW) #B1 0
time.sleep(0.01)
gpio.output(b2, gpio.LOW) #B2 0
time.sleep(0.01)
    
gpio.cleanup()