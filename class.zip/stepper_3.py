import RPi.GPIO as gpio
import time

a1 = 17
a2 = 22
b1 = 27
b2 = 18

delay = 0.005

def setup():
    gpio.setmode(gpio.BCM)
    gpio.setup(17, gpio.OUT)
    gpio.setup(22, gpio.OUT)
    gpio.setup(27, gpio.OUT)
    gpio.setup(18, gpio.OUT)
    
def forwardStep():
    setStepper(1,0,1,0)
    setStepper(0,1,1,0)
    setStepper(0,1,0,1)
    setStepper(1,0,0,1)
    
def backwardStep():
    setStepper(1,0,0,1)
    setStepper(0,1,0,1)
    setStepper(0,1,1,0)
    setStepper(1,0,1,0)
    
def setStepper(in1, in2, in3, in4):
    gpio.output(a1, in1)
    gpio.output(a2, in2)
    gpio.output(b1, in3)
    gpio.output(b2, in4)
    time.sleep(delay)
    
setup()

while True:
    try:
        print("forward")
        for i in range(50):
            forwardStep()
        print("backward")
        for i in range(50):
            backwardStep()
        
    except KeyboardInterrupt:
         gpio.cleanup()
         break
    

    
