from picamera import PiCamera
from time import sleep

cam = PiCamera()

try:
    cam.start_preview()
    sleep(1)
    cam.capture('/home/pi/Desktop/jibz.jpg')
    cam.stop_preview()
    print("Image captured")
except:
    print("error")