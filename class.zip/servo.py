import RPi.GPIO as gpio
from time import sleep

gpio.setmode(gpio.BCM)
gpio.setup(21, gpio.OUT)
pwm = gpio.PWM(21, 50)
pwm.start(0)
sleep(0.1)
pwm.ChangeDutyCycle(2)
sleep(0.1)
pwm.stop()
gpio.cleanup()