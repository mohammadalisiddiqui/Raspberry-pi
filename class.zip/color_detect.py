import cv2
import numpy as np

raw_img = cv2.imread('/home/pi/Desktop/red.jpg')

raw_img = cv2.cvtColor(raw_img, cv2.COLOR_BGR2HSV)

red_low_r = np.array([170, 50, 50])
red_high_r = np.array([180, 255, 255])

img = cv2.inRange(raw_img, red_low_r, red_high_r)

cv2.imshow('img', img)

cv2.waitKey(0)

cv2.destroyAllWindows()